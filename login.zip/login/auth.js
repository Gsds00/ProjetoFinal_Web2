const bcrypt = require('bcryptjs');
const LocalStrategy = require('passport-local').Strategy;
 
const users = [{ 
    _id: 1, 
    username: "kirigaia777", 
    password: "123",
    email: "kirigaiaasunalova@gmail.com"
}];
 
module.exports = function(passport){
   //configuraremos o passport aqui
}
function findUser(username){
    return users.find(user => user.username === username);
}

function findUserById(id){
    return users.find(user => user._id === id);
}
JavaScript
    passport.serializeUser((user, done) => {
        done(null, user._id); //-this fuction done  nativa” do passport  serve para sinalizar erro e passar informações do usuário para o passport
    });

    passport.deserializeUser((id, done) => {
        try {
            const user = findUserById(id);
            done(null, user);
        } catch (err) {
            done(err, null);
        }
    });
//security  no save  cookies    --> kirigaia 777
    passport.serializeUser((user, done) => {
        done(null, user._id);
    });
 
    passport.deserializeUser((id, done) => {
        try {
            const user = findUserById(id);
            done(null, user);
        } catch (err) {
            done(err, null);
        }
    });